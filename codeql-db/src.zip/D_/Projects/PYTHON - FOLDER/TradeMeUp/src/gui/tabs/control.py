"""
Agent Control Tab - Start, Stop and Monitor Agents
"""

import logging
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import dash
import dash_bootstrap_components as dbc
from dash import dcc, html, Input, Output, State

from src.utils.activity_logger import activity_logger
from src.utils.process_utils import stop_process

# Get project root
PROJECT_ROOT = Path(__file__).parent.parent.parent.parent
logger = logging.getLogger(__name__)


def create_layout():
    """Create agent control tab layout"""
    return dbc.Container([
        # Control Panel
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H5("🎮 Pipeline Control Panel")),
                    dbc.CardBody([
                        dbc.Row([
                            # Full Pipeline
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.H6("🚀 Full MVP Pipeline", className="text-primary"),
                                        html.P("Run all 8 agents sequentially", className="text-muted small"),
                                        dbc.Button(
                                            "Run Full Pipeline",
                                            id="btn-run-full-pipeline",
                                            color="primary",
                                            className="w-100 mb-2"
                                        ),
                                        html.Small("~15 minutes", className="text-muted")
                                    ])
                                ], className="h-100")
                            ], width=4),
                            
                            # Quick Test
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.H6("⚡ Quick Test", className="text-success"),
                                        html.P("Process 3 articles (fast test)", className="text-muted small"),
                                        dbc.Button(
                                            "Run Quick Test",
                                            id="btn-run-quick-test",
                                            color="success",
                                            className="w-100 mb-2"
                                        ),
                                        html.Small("~2 minutes", className="text-muted")
                                    ])
                                ], className="h-100")
                            ], width=4),
                            
                            # Single Agent
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.H6("🎯 Single Agent", className="text-info"),
                                        html.P("Run individual agent", className="text-muted small"),
                                        dcc.Dropdown(
                                            id="agent-selector",
                                            options=[
                                                {"label": "Agent 1: Ingestion", "value": "ingestion"},
                                                {"label": "Agent 1.5: Data Quality", "value": "quality"},
                                                {"label": "Agent 2: Content Understanding", "value": "content"},
                                                {"label": "Agent 3: Entity Mapping", "value": "entity"},
                                                {"label": "Agent 4: Impact Scoring", "value": "impact"},
                                                {"label": "Agent 4.5: Surprise Quantification", "value": "surprise"},
                                                {"label": "Agent 5: Regime Detection", "value": "regime"},
                                                {"label": "Agent 6: Predictions", "value": "predictions"},
                                                {"label": "Agent 7: Fact Verification", "value": "fact_verification"},
                                                {"label": "Agent 8: Correlation Analysis", "value": "correlation"},
                                                {"label": "Agent 9: Signal Decay", "value": "signal_decay"},
                                                {"label": "Agent 10: Scenario Generation", "value": "scenarios"},
                                                {"label": "Agent 11: Confidence Calibration", "value": "calibration"},
                                                {"label": "Agent 12: Meta Strategy", "value": "meta_strategy"},
                                                {"label": "Agent 13: Model Performance", "value": "performance"},
                                                {"label": "Agent 14: A/B Testing", "value": "ab_testing"}
                                            ],
                                            placeholder="Select agent...",
                                            className="mb-2"
                                        ),
                                        dbc.Button(
                                            "Run Selected Agent",
                                            id="btn-run-single-agent",
                                            color="info",
                                            className="w-100",
                                            disabled=True
                                        )
                                    ])
                                ], className="h-100")
                            ], width=4)
                        ])
                    ])
                ])
            ], width=12)
        ], className="mb-3"),
        
        # Backfill Operations Section
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H5("🔄 Backfill Operations")),
                    dbc.CardBody([
                        html.P("Process existing articles for missing analyses", className="text-muted mb-3"),
                        dbc.Row([
                            # Full Backfill
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.H6("🔄 Full Backfill", className="text-warning"),
                                        html.P("Complete all missing analyses", className="text-muted small"),
                                        dbc.Button(
                                            "Run Full Backfill",
                                            id="btn-run-full-backfill",
                                            color="warning",
                                            className="w-100 mb-2"
                                        ),
                                        html.Small("All phases", className="text-muted")
                                    ])
                                ], className="h-100")
                            ], width=3),
                            
                            # Selective Backfill
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.H6("🎯 Selective Backfill", className="text-info"),
                                        html.P("Choose specific analyses", className="text-muted small"),
                                        dbc.Checklist(
                                            id="check-backfill-phases",
                                            options=[
                                                {"label": " Quality Assessment", "value": "quality"},
                                                {"label": " Content Understanding", "value": "content"},
                                                {"label": " Entity Mapping", "value": "entities"},
                                                {"label": " Fact Verification", "value": "facts"},
                                                {"label": " Surprise Scoring", "value": "surprises"},
                                                {"label": " Impact Scoring", "value": "impact"},
                                                {"label": " Predictions", "value": "predictions"}
                                            ],
                                            value=["facts", "surprises", "predictions"],
                                            className="small"
                                        ),
                                        dbc.Button(
                                            "Run Selected Phases",
                                            id="btn-run-selective-backfill",
                                            color="info",
                                            className="w-100 mt-2",
                                            size="sm"
                                        )
                                    ])
                                ], className="h-100")
                            ], width=5),
                            
                            # Backfill Options
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.H6("⚙️ Backfill Settings", className="text-secondary"),
                                        dbc.Label("Batch Size:", className="small"),
                                        dcc.Slider(
                                            id="slider-backfill-batch",
                                            min=10,
                                            max=100,
                                            step=10,
                                            value=50,
                                            marks={10: "10", 50: "50", 100: "100"},
                                            tooltip={"placement": "bottom", "always_visible": True}
                                        ),
                                        html.Small("Articles per batch", className="text-muted d-block mb-2"),
                                        dbc.Checklist(
                                            id="check-backfill-openai",
                                            options=[{"label": " Use OpenAI (faster)", "value": "openai"}],
                                            value=["openai"],
                                            className="small"
                                        )
                                    ])
                                ], className="h-100")
                            ], width=4)
                        ])
                    ])
                ])
            ], width=12)
        ], className="mb-3"),
        
        # Pipeline Options
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("⚙️ Pipeline Options")),
                    dbc.CardBody([
                        dbc.Row([
                            dbc.Col([
                                dbc.Label("Articles to Process:"),
                                dcc.Slider(
                                    id="slider-article-limit",
                                    min=1,
                                    max=50,
                                    step=1,
                                    value=10,
                                    marks={1: "1", 10: "10", 25: "25", 50: "50"},
                                    tooltip={"placement": "bottom", "always_visible": True}
                                )
                            ], width=4),
                            dbc.Col([
                                dbc.Checklist(
                                    id="check-force-refresh",
                                    options=[{"label": " Force Refresh (ignore cache)", "value": "force"}],
                                    value=[],
                                    className="mt-4"
                                )
                            ], width=4),
                            dbc.Col([
                                dbc.Checklist(
                                    id="check-verbose",
                                    options=[{"label": " Verbose Logging", "value": "verbose"}],
                                    value=["verbose"],
                                    className="mt-4"
                                )
                            ], width=4)
                        ])
                    ])
                ])
            ], width=12)
        ], className="mb-3"),
        
        # Status Display
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader([
                        html.H6("📊 Execution Status", className="d-inline"),
                        dbc.Badge("Idle", id="badge-pipeline-status", color="secondary", className="ms-2")
                    ]),
                    dbc.CardBody([
                        html.Div(id="pipeline-status-display", children=[
                            html.P("No pipeline running. Select an option above to start.", className="text-muted")
                        ])
                    ])
                ])
            ], width=6),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("📝 Execution Log")),
                    dbc.CardBody([
                        dcc.Textarea(
                            id="pipeline-log",
                            value="Waiting for pipeline execution...\n",
                            style={"width": "100%", "height": "300px", "fontFamily": "monospace", "fontSize": "12px"},
                            readOnly=True
                        )
                    ])
                ])
            ], width=6)
        ], className="mb-3"),
        
        # Recent Executions
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("📜 Recent Executions")),
                    dbc.CardBody([
                        html.Div(id="recent-executions")
                    ])
                ])
            ], width=12)
        ]),
        
        # Hidden stores for state management
        dcc.Store(id="store-pipeline-state", data={"running": False, "process_id": None}),
        dcc.Store(id="store-execution-history", data=[]),
        dcc.Interval(id="interval-pipeline-monitor", interval=2000, disabled=True)  # 2 seconds when active
        
    ], fluid=True)


def get_recent_executions():
    """Get recent execution history"""
    # This would be loaded from a database or log file in production
    # For now, return placeholder
    return html.Div([
        html.Small("Execution history will appear here", className="text-muted")
    ])


def format_pipeline_status(status):
    """Format pipeline status display"""
    if not status or not status.get("running"):
        return html.Div([
            html.P("No pipeline running.", className="text-muted"),
            html.Small("Use the control panel above to start a pipeline.", className="text-muted")
        ])
    
    return html.Div([
        dbc.Progress(value=status.get("progress", 0), className="mb-2"),
        html.P([
            html.Strong("Current Phase: "),
            html.Span(status.get("phase", "Unknown"), className="text-primary")
        ]),
        html.P([
            html.Strong("Started: "),
            html.Span(status.get("start_time", "Unknown"))
        ]),
        html.P([
            html.Strong("Articles Processed: "),
            html.Span(f"{status.get('processed', 0)}/{status.get('total', 0)}")
        ])
    ])


def run_pipeline_command(command_type, options=None):
    """
    Execute pipeline command
    
    Args:
        command_type: 'full', 'quick', 'backfill', 'backfill_selective', or agent name
        options: dict with limit, force, verbose flags, backfill phases, batch_size
    """
    options = options or {}
    
    # Get Python executable path
    python_exe = os.path.join(PROJECT_ROOT, "venv", "Scripts", "python.exe")
    
    # Build command based on type
    if command_type == "full":
        script = os.path.join(PROJECT_ROOT, "scripts", "run_mvp_pipeline.py")
        cmd = [python_exe, script]
    elif command_type == "quick":
        script = os.path.join(PROJECT_ROOT, "scripts", "run_mvp_pipeline.py")
        cmd = [python_exe, script, "--quick"]
    elif command_type == "backfill":
        # Full backfill - all phases
        script = os.path.join(PROJECT_ROOT, "scripts", "backfill_all_agents.py")
        cmd = [python_exe, script]
        if options.get("batch_size"):
            cmd.extend(["--batch-size", str(options["batch_size"])])
    elif command_type == "backfill_selective":
        # Selective backfill - skip phases not selected
        script = os.path.join(PROJECT_ROOT, "scripts", "backfill_all_agents.py")
        cmd = [python_exe, script]
        
        # Add skip flags for unselected phases
        all_phases = ["quality", "content", "entities", "facts", "surprises", "impact", "predictions"]
        selected_phases = options.get("phases", [])
        for phase in all_phases:
            if phase not in selected_phases:
                cmd.append(f"--skip-{phase}")
        
        if options.get("batch_size"):
            cmd.extend(["--batch-size", str(options["batch_size"])])
    elif command_type == "ingestion":
        script = os.path.join(PROJECT_ROOT, "scripts", "run_ingestion.py")
        cmd = [python_exe, script]
    else:
        # For other agents, we'd need individual scripts or parameters
        return None, "Agent-specific scripts not yet implemented"
    
    # Add options
    if options.get("limit"):
        cmd.extend(["--limit", str(options["limit"])])
    if options.get("force"):
        cmd.append("--force")
    if options.get("verbose"):
        cmd.append("--verbose")
    
    try:
        # Start process (non-blocking)
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            cwd=PROJECT_ROOT
        )
        return process, None
    except Exception as e:
        return None, str(e)


def get_process_output(process):
    """Get output from running process"""
    if not process:
        return ""
    
    try:
        # Non-blocking read
        output = []
        while True:
            line = process.stdout.readline()
            if not line:
                break
            output.append(line)
        return "".join(output)
    except Exception:
        return ""


def register_callbacks(app):
    """Register control tab callbacks (continuous pipeline, RSS fetch, status)."""

    @app.callback(
        [
            Output("continuous-pipeline-state", "data"),
            Output("btn-start-continuous", "disabled"),
            Output("btn-stop-continuous", "disabled"),
        ],
        [Input("btn-start-continuous", "n_clicks"), Input("btn-stop-continuous", "n_clicks")],
        State("continuous-pipeline-state", "data"),
        prevent_initial_call=True,
    )
    def control_continuous_pipeline(start_clicks, stop_clicks, current_state):
        ctx = dash.callback_context
        if not ctx.triggered:
            return dash.no_update
        button_id = ctx.triggered[0]["prop_id"].split(".")[0]
        if button_id == "btn-start-continuous":
            logger.info("Starting continuous pipeline with Python: %s", sys.executable)
            wrapper_script = Path("scripts/run_continuous_pipeline_wrapper.bat").absolute()
            if not wrapper_script.exists():
                error_msg = "Wrapper script not found: %s" % wrapper_script
                activity_logger.log_activity(error_msg, "ERROR")
                logger.error(error_msg)
                return dash.no_update
            try:
                cmd = 'start "ANPS-TradeMeUp Pipeline" /D "%s" "%s" --interval 300' % (
                    Path.cwd(),
                    wrapper_script,
                )
                process = subprocess.Popen(cmd, shell=True, cwd=str(Path.cwd()))
                logger.info("Started pipeline with command: %s", cmd)
                activity_logger.log_activity(
                    "Continuous Pipeline console opened - Check the new terminal window",
                    "SUCCESS",
                )
                logger.info("Pipeline console started with PID: %s", process.pid)
                return ({"running": True, "pid": process.pid}, True, False)
            except Exception as e:
                activity_logger.log_activity("Failed to start continuous pipeline: %s" % e, "ERROR")
                logger.error("Failed to start: %s", e, exc_info=True)
                return dash.no_update
        if button_id == "btn-stop-continuous":
            if current_state and current_state.get("pid"):
                success, message = stop_process(current_state["pid"])
                if success:
                    activity_logger.log_activity("Continuous Pipeline STOPPED: %s" % message, "INFO")
                else:
                    activity_logger.log_activity("Warning stopping pipeline: %s" % message, "WARNING")
            return ({"running": False, "pid": None}, False, True)
        return dash.no_update

    @app.callback(
        Output("rss-fetch-status-store", "data"),
        Input("btn-fetch-rss-only", "n_clicks"),
        prevent_initial_call=True,
    )
    def fetch_rss_only(n_clicks):
        if not n_clicks:
            return dash.no_update
        try:
            wrapper_script = Path("scripts/run_rss_fetch_wrapper.bat").absolute()
            if not wrapper_script.exists():
                error_msg = "RSS fetch script not found: %s" % wrapper_script
                activity_logger.log_activity(error_msg, "ERROR")
                logger.error(error_msg)
                return {"status": "error", "message": str(error_msg)}
            cmd = 'start "ANPS-TradeMeUp RSS Fetch" /D "%s" "%s"' % (Path.cwd(), wrapper_script)
            subprocess.Popen(cmd, shell=True, cwd=str(Path.cwd()))
            logger.info("RSS fetch terminal opened with command: %s", cmd)
            activity_logger.log_activity(
                "RSS Feed Fetch: Terminal window opened - Check the new window",
                "INFO",
            )
            return {"status": "success", "message": "RSS fetch started in new terminal"}
        except Exception as e:
            logger.error("Error opening RSS fetch terminal: %s", e, exc_info=True)
            activity_logger.log_activity("RSS Fetch Error: %s" % str(e), "ERROR")
            return {"status": "error", "message": str(e)}

    @app.callback(
        Output("continuous-status", "children"),
        Input("interval-component", "n_intervals"),
        State("continuous-pipeline-state", "data"),
    )
    def update_continuous_status(n, state):
        if state and state.get("running"):
            return html.Div([
                html.Span("🔄 ", className="text-success"),
                html.Small("Auto Mode", className="text-success fw-bold"),
            ])
        return html.Div([
            html.Span("⏸️ ", className="text-muted"),
            html.Small("Manual Mode", className="text-muted"),
        ])

    @app.callback(
        Output("btn-run-single-agent", "disabled"),
        Input("agent-selector", "value"),
    )
    def toggle_single_agent_button(selected_agent):
        return selected_agent is None

    @app.callback(
        [
            Output("pipeline-log", "value", allow_duplicate=True),
            Output("badge-pipeline-status", "children", allow_duplicate=True),
            Output("badge-pipeline-status", "color", allow_duplicate=True),
        ],
        Input("interval-component", "n_intervals"),
        State("store-pipeline-state", "data"),
        prevent_initial_call=True,
    )
    def update_pipeline_log(n, state):
        if not state or not state.get("running"):
            return dash.no_update
        try:
            output_file = Path("logs") / "pipeline_output.log"
            if output_file.exists():
                with open(output_file, "r", encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
                    recent = "".join(lines[-100:])
                if "PIPELINE COMPLETE" in recent or "COMPLETED SUCCESSFULLY" in recent:
                    return recent, "COMPLETED", "success"
                if "ERROR" in recent and "Traceback" in recent:
                    return recent, "ERROR", "danger"
                return recent, "RUNNING", "warning"
            log_file = Path("logs") / "pipeline_activity.log"
            if log_file.exists():
                with open(log_file, "r", encoding="utf-8", errors="ignore") as f:
                    recent = "".join(f.readlines()[-50:])
                return recent, "RUNNING", "warning"
        except Exception:
            pass
        return dash.no_update

    @app.callback(
        [
            Output("store-pipeline-state", "data", allow_duplicate=True),
            Output("pipeline-log", "value", allow_duplicate=True),
            Output("badge-pipeline-status", "children", allow_duplicate=True),
            Output("badge-pipeline-status", "color", allow_duplicate=True),
        ],
        Input("btn-run-full-pipeline", "n_clicks"),
        [State("slider-article-limit", "value"), State("check-force-refresh", "value"), State("check-verbose", "value")],
        prevent_initial_call=True,
    )
    def run_full_pipeline(n_clicks, limit, force, verbose):
        if not n_clicks:
            return dash.no_update
        activity_logger.log_activity("User initiated Full MVP Pipeline from GUI", "INFO")
        activity_logger.log_pipeline_start("ANPS-TradeMeUp MVP Pipeline (GUI)")
        wrapper = Path("scripts/run_mvp_pipeline_wrapper.bat").absolute()
        if not wrapper.exists():
            msg = f"Wrapper script not found: {wrapper}"
            activity_logger.log_activity(msg, "ERROR")
            return {"running": False}, msg, "ERROR", "danger"
        try:
            cmd = f'start "ANPS-TradeMeUp MVP Pipeline" /D "{Path.cwd()}" "{wrapper}"'
            proc = subprocess.Popen(cmd, shell=True, cwd=str(Path.cwd()))
        except Exception as e:
            activity_logger.log_agent_error("Full Pipeline (GUI)", str(e))
            return {"running": False}, str(e), "ERROR", "danger"
        state = {"running": True, "process_id": proc.pid, "start_time": datetime.now().strftime("%H:%M:%S"), "type": "full_pipeline"}
        log = f"[{datetime.now().strftime('%H:%M:%S')}] Full MVP Pipeline console opened\nProcess ID: {proc.pid}\nArticles: {limit}\n" + "-" * 60 + "\nCheck the new terminal window for live progress!\n"
        activity_logger.log_activity(f"Pipeline process started (PID: {proc.pid})", "SUCCESS")
        return state, log, "RUNNING", "warning"

    @app.callback(
        [
            Output("store-pipeline-state", "data", allow_duplicate=True),
            Output("pipeline-log", "value", allow_duplicate=True),
            Output("badge-pipeline-status", "children", allow_duplicate=True),
            Output("badge-pipeline-status", "color", allow_duplicate=True),
        ],
        Input("btn-run-quick-test", "n_clicks"),
        prevent_initial_call=True,
    )
    def run_quick_test(n_clicks):
        if not n_clicks:
            return dash.no_update
        activity_logger.log_activity("User initiated Quick Test from GUI", "INFO")
        wrapper = Path("scripts/run_mvp_pipeline_wrapper.bat").absolute()
        if not wrapper.exists():
            msg = f"Wrapper script not found: {wrapper}"
            activity_logger.log_activity(msg, "ERROR")
            return {"running": False}, msg, "ERROR", "danger"
        try:
            cmd = f'start "ANPS-TradeMeUp Quick Test" /D "{Path.cwd()}" "{wrapper}" --quick'
            proc = subprocess.Popen(cmd, shell=True, cwd=str(Path.cwd()))
        except Exception as e:
            activity_logger.log_agent_error("Quick Test (GUI)", str(e))
            return {"running": False}, str(e), "ERROR", "danger"
        state = {"running": True, "process_id": proc.pid, "start_time": datetime.now().strftime("%H:%M:%S"), "type": "quick_test"}
        log = f"[{datetime.now().strftime('%H:%M:%S')}] Quick Test console opened\nProcess ID: {proc.pid}\n" + "-" * 60 + "\nCheck the new terminal window for live progress!\n"
        activity_logger.log_activity(f"Quick test started (PID: {proc.pid})", "SUCCESS")
        return state, log, "RUNNING", "warning"

    @app.callback(
        [
            Output("store-pipeline-state", "data", allow_duplicate=True),
            Output("pipeline-log", "value", allow_duplicate=True),
            Output("badge-pipeline-status", "children", allow_duplicate=True),
            Output("badge-pipeline-status", "color", allow_duplicate=True),
        ],
        Input("btn-run-full-backfill", "n_clicks"),
        State("slider-backfill-batch", "value"),
        prevent_initial_call=True,
    )
    def run_full_backfill(n_clicks, batch_size):
        if not n_clicks:
            return dash.no_update
        activity_logger.log_activity("User initiated Full Backfill from GUI", "INFO")
        wrapper = Path("scripts/run_backfill_wrapper.bat").absolute()
        if not wrapper.exists():
            msg = f"Wrapper script not found: {wrapper}"
            activity_logger.log_activity(msg, "ERROR")
            return {"running": False}, msg, "ERROR", "danger"
        try:
            cmd = f'start "ANPS-TradeMeUp Backfill" /D "{Path.cwd()}" "{wrapper}" --batch-size {batch_size}'
            proc = subprocess.Popen(cmd, shell=True, cwd=str(Path.cwd()))
        except Exception as e:
            activity_logger.log_agent_error("Backfill (GUI)", str(e))
            return {"running": False}, str(e), "ERROR", "danger"
        state = {"running": True, "process_id": proc.pid, "start_time": datetime.now().strftime("%H:%M:%S"), "type": "full_backfill"}
        log = f"[{datetime.now().strftime('%H:%M:%S')}] Full Backfill console opened\nProcess ID: {proc.pid}\nBatch: {batch_size}\n" + "-" * 60 + "\nCheck the new terminal window for live progress!\n"
        activity_logger.log_activity(f"Full backfill started (PID: {proc.pid})", "SUCCESS")
        return state, log, "RUNNING", "warning"

    @app.callback(
        [
            Output("store-pipeline-state", "data", allow_duplicate=True),
            Output("pipeline-log", "value", allow_duplicate=True),
            Output("badge-pipeline-status", "children", allow_duplicate=True),
            Output("badge-pipeline-status", "color", allow_duplicate=True),
        ],
        Input("btn-run-selective-backfill", "n_clicks"),
        [State("check-backfill-phases", "value"), State("slider-backfill-batch", "value")],
        prevent_initial_call=True,
    )
    def run_selective_backfill(n_clicks, selected_phases, batch_size):
        if not n_clicks or not selected_phases:
            return dash.no_update
        activity_logger.log_activity("User initiated Selective Backfill from GUI", "INFO")
        wrapper = Path("scripts/run_backfill_wrapper.bat").absolute()
        if not wrapper.exists():
            msg = f"Wrapper script not found: {wrapper}"
            activity_logger.log_activity(msg, "ERROR")
            return {"running": False}, msg, "ERROR", "danger"
        all_phases = ["quality", "content", "entities", "facts", "surprises", "impact", "predictions"]
        args = ["--batch-size", str(batch_size)]
        for p in all_phases:
            if p not in selected_phases:
                args.append(f"--skip-{p}")
        try:
            cmd = f'start "ANPS-TradeMeUp Backfill" /D "{Path.cwd()}" "{wrapper}" {" ".join(args)}'
            proc = subprocess.Popen(cmd, shell=True, cwd=str(Path.cwd()))
        except Exception as e:
            activity_logger.log_agent_error("Backfill (GUI)", str(e))
            return {"running": False}, str(e), "ERROR", "danger"
        state = {"running": True, "process_id": proc.pid, "start_time": datetime.now().strftime("%H:%M:%S"), "type": "selective_backfill"}
        phase_names = {"quality": "Quality Assessment", "content": "Content Understanding", "entities": "Entity Mapping", "facts": "Fact Verification", "surprises": "Surprise Scoring", "impact": "Impact Scoring", "predictions": "Predictions"}
        log = f"[{datetime.now().strftime('%H:%M:%S')}] Selective Backfill started\nProcess ID: {proc.pid}\nBatch: {batch_size}\n"
        for ph in selected_phases:
            log += f"  ✓ {phase_names.get(ph, ph)}\n"
        log += "-" * 60 + "\n"
        activity_logger.log_activity(f"Selective backfill started (PID: {proc.pid})", "SUCCESS")
        return state, log, "RUNNING", "warning"

    @app.callback(
        Output("recent-executions", "children"),
        Input("interval-component", "n_intervals"),
    )
    def update_recent_executions_cb(n):
        return get_recent_executions()
