"""
System Health Tab - Monitor Agent Status and Performance
"""

import dash_bootstrap_components as dbc
from dash import Input, Output, html
from sqlalchemy import func
from sqlalchemy.orm import Session

from src.models.database import engine as _engine
from src.gui.utils.callbacks import safe_callback
from src.models.raw_news import RawNews
from src.models.processed_news import ProcessedNews
from src.models.entities import Entity
from src.models.predictions import Prediction
from src.models.analysis import ImpactScore, SurpriseScore, SignalDecayModel, FactVerification, MarketRegime
from src.models.data_quality import DataQualityScore


def create_layout():
    """Create system health tab layout"""
    return dbc.Container([
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H5("🤖 Agent Pipeline Status")),
                    dbc.CardBody([
                        html.Div(id="agent-status")
                    ])
                ])
            ], width=12)
        ], className="mb-3"),
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H5("📊 Database Statistics")),
                    dbc.CardBody([
                        html.Div(id="db-statistics")
                    ])
                ])
            ], width=6),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H5("⚡ Processing Pipeline")),
                    dbc.CardBody([
                        html.Div(id="pipeline-stats")
                    ])
                ])
            ], width=6)
        ])
    ], fluid=True)


def get_agent_status():
    """Get agent status display"""
    agents = [
        ("Agent 1", "Data Ingestion", "✅ Operational", "success"),
        ("Agent 1.5", "Data Quality", "✅ Operational", "success"),
        ("Agent 2", "Content Understanding", "✅ Operational", "success"),
        ("Agent 2.5", "Fact Verification", "✅ Operational", "success"),
        ("Agent 3", "Entity Mapping", "✅ Operational", "success"),
        ("Agent 4", "Impact Scoring", "✅ Operational", "success"),
        ("Agent 4.5", "Surprise Quantification", "✅ Operational", "success"),
        ("Agent 5", "Market Regime Detection", "✅ Operational", "success"),
        ("Agent 5.5", "Signal Decay", "✅ Operational", "success"),
        ("Agent 5.6", "Correlation Analysis", "✅ Operational", "success"),
        ("Agent 6", "Predictions", "✅ Operational", "success"),
        ("Agent 6.5", "Confidence Calibration", "✅ Operational", "success"),
        ("Agent 7", "Meta-Strategy", "✅ Operational", "success"),
        ("Agent 7.5", "Scenario Generation", "✅ Operational", "success"),
        ("Agent 12.5", "Model Performance Monitor", "✅ Operational", "success"),
        ("Agent 13", "A/B Testing Framework", "✅ Operational", "success")
    ]
    
    rows = []
    for agent_id, name, status, color in agents:
        rows.append(html.Tr([
            html.Td(agent_id, className="text-primary"),
            html.Td(name),
            html.Td(status, className=f"text-{color}")
        ]))
    
    return dbc.Table([
        html.Thead(html.Tr([
            html.Th("Agent ID"),
            html.Th("Name"),
            html.Th("Status")
        ])),
        html.Tbody(rows)
    ], bordered=True, hover=True, className="table-dark")


def get_db_statistics(engine):
    """Get database statistics"""
    try:
        with Session(engine) as db:
            stats = {
                "📰 Raw News": db.query(func.count(RawNews.news_id)).scalar() or 0,
                "✅ Data Quality Scores": db.query(func.count(DataQualityScore.news_id)).scalar() or 0,
                "🧠 Processed News": db.query(func.count(ProcessedNews.news_id)).scalar() or 0,
                "🏢 Entities": db.query(func.count(Entity.entity_id)).scalar() or 0,
                "⚡ Impact Scores": db.query(func.count(ImpactScore.score_id)).scalar() or 0,
                "🎯 Surprise Scores": db.query(func.count(SurpriseScore.surprise_id)).scalar() or 0,
                "🔍 Fact Verifications": db.query(func.count(FactVerification.verification_id)).scalar() or 0,
                "🌡️ Market Regimes": db.query(func.count(MarketRegime.regime_id)).scalar() or 0,
                "📉 Signal Decay Models": db.query(func.count(SignalDecayModel.news_id)).scalar() or 0,
                "🔮 Predictions": db.query(func.count(Prediction.prediction_id)).scalar() or 0
            }
        
        items = []
        for key, value in stats.items():
            items.append(html.Div([
                html.Strong(f"{key}: "),
                html.Span(f"{value:,}", className="text-primary ms-2")
            ], className="mb-2"))
        
        return html.Div(items)
    except Exception as e:
        return html.Div([
            html.P("⚠️ Unable to load database statistics", className="text-warning mb-2"),
            html.Small("Database may be empty. Run the pipeline to generate data.", className="text-muted")
        ])


def get_pipeline_stats(engine):
    """Get pipeline processing stats"""
    try:
        with Session(engine) as db:
            total_news = db.query(func.count(RawNews.news_id)).scalar() or 0
            processed = db.query(func.count(ProcessedNews.news_id)).scalar() or 0
            
            processing_rate = (processed / total_news * 100) if total_news > 0 else 0
        
        return html.Div([
            html.Div([
                html.H4(f"{processing_rate:.1f}%", className="text-success"),
                html.P("Processing Completion Rate", className="text-muted")
            ], className="text-center mb-3"),
            dbc.Progress(value=processing_rate, color="success", className="mb-2"),
            html.Small(f"{processed:,} of {total_news:,} articles processed", className="text-muted")
        ])
    except Exception as e:
        return html.Div([
            html.P("⚠️ Unable to load pipeline stats", className="text-warning mb-2"),
            html.Small("Database may be empty. Run the pipeline to generate data.", className="text-muted")
        ])


def register_callbacks(app):
    """Register system tab callbacks."""

    @app.callback(
        Output("agent-status", "children"),
        Input("interval-component", "n_intervals"),
    )
    def _update_agent_status(n):
        return get_agent_status()

    @app.callback(
        Output("db-statistics", "children"),
        Input("interval-component", "n_intervals"),
    )
    @safe_callback(default_return=html.Div("Unable to load database statistics", className="text-warning"))
    def _update_db_statistics(n):
        return get_db_statistics(_engine)

    @app.callback(
        Output("pipeline-stats", "children"),
        Input("interval-component", "n_intervals"),
    )
    @safe_callback(default_return=html.Div("Unable to load pipeline statistics", className="text-warning"))
    def _update_pipeline_stats(n):
        return get_pipeline_stats(_engine)
