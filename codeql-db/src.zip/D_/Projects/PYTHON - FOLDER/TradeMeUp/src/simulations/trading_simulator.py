"""Trading simulation engine that converts predictions into trade decisions."""
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import logging
import json
from pathlib import Path

from sqlalchemy.orm import Session

from src.models.database import get_scoped_session
from src.models.predictions import Prediction
from src.models.entities import Entity
from src.models.analysis import MarketRegime
from src.models.trading_simulation import TradingSimulation
from src.services.prediction_performance_service import PredictionPerformanceService
from src.services.market_data import MarketDataProvider
from src.simulations.risk_calculations import RiskCalculator, RiskInputs

logger = logging.getLogger(__name__)


class TradingSimulationEngine:
    """Simulate trades based on predictions and risk framework."""

    DEFAULT_SHARES = 100
    MIN_CONFIDENCE = 0.55
    MIN_EXPECTED_RETURN_PCT = 0.75
    MAX_RISK_SCORE = 0.65
    MAX_COST_RATIO = 0.70

    def __init__(
        self,
        market_data_provider: Optional[MarketDataProvider] = None,
        performance_service: Optional[PredictionPerformanceService] = None,
        risk_calculator: Optional[RiskCalculator] = None,
        config_path: Optional[str] = None,
    ):
        self.market_data_provider = market_data_provider or MarketDataProvider()
        self.performance_service = performance_service or PredictionPerformanceService()
        self.risk_calculator = risk_calculator or RiskCalculator()
        self._market_cache: Dict[str, Dict] = {}
        self._market_cache_ttl = timedelta(minutes=10)

        # Load simulation parameters from config
        self.config = self._load_config(config_path)
        self._update_thresholds_from_config()

    def _load_config(self, config_path: Optional[str] = None) -> Dict:
        """Load simulation parameters from JSON config file."""
        if config_path is None:
            # Default path relative to project root
            config_path = Path(__file__).parent.parent.parent / "config" / "simulation_params.json"
        else:
            config_path = Path(config_path)

        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                logger.info(f"Loaded simulation config from {config_path}")
                return config
        except FileNotFoundError:
            logger.warning(f"Config file not found at {config_path}, using defaults")
            return self._get_default_config()
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in config file: {e}, using defaults")
            return self._get_default_config()

    def _get_default_config(self) -> Dict:
        """Fallback default configuration if file not found."""
        return {
            "cost_parameters": {
                "commission": {"per_share": 0.005},
                "spread_bps": {"low_volatility": 4.0, "medium_volatility": 8.0, "high_volatility": 12.0},
                "slippage_bps": {"normal": 5.0, "high_volatility": 9.0},
                "market_impact_bps": {"small_order": 6.0, "medium_order": 12.0},
                "overnight_financing": {"long_position_bps_per_day": 1.1, "short_position_bps_per_day": 1.4},
                "short_borrow_costs": {"easy_to_borrow_annual_pct": 0.5},
                "regulatory_fees": {"sec_fee_bps": 0.278}
            },
            "position_constraints": {
                "max_position_size_pct": 10.0,
                "max_daily_volume_participation_pct": 5.0
            },
            "decision_thresholds": {
                "min_confidence": 0.55,
                "min_expected_return_pct": 0.75,
                "max_risk_score": 0.65,
                "max_cost_ratio": 0.70
            }
        }

    def _update_thresholds_from_config(self):
        """Update decision thresholds from loaded config."""
        thresholds = self.config.get("decision_thresholds", {})
        self.MIN_CONFIDENCE = thresholds.get("min_confidence", self.MIN_CONFIDENCE)
        self.MIN_EXPECTED_RETURN_PCT = thresholds.get("min_expected_return_pct", self.MIN_EXPECTED_RETURN_PCT)
        self.MAX_RISK_SCORE = thresholds.get("max_risk_score", self.MAX_RISK_SCORE)
        self.MAX_COST_RATIO = thresholds.get("max_cost_ratio", self.MAX_COST_RATIO)

    def _get_expected_return_pct(self, prediction: Prediction) -> float:
        expected_return = prediction.expected_return or {}
        mean_value = expected_return.get("mean", 0.0) if isinstance(expected_return, dict) else 0.0
        # Heuristic: if value is in [-1, 1], treat as fraction and convert to percent.
        return float(mean_value * 100.0) if abs(mean_value) <= 1.0 else float(mean_value)

    def _get_predicted_direction(self, prediction: Prediction) -> str:
        probabilities = prediction.direction_probabilities or {}
        if not probabilities:
            return "flat"
        return max(probabilities, key=probabilities.get)

    def _get_latest_regime(self, db: Session) -> Optional[MarketRegime]:
        return db.query(MarketRegime).order_by(MarketRegime.created_at.desc()).first()

    def _regime_liquidity_stress(self, regime: Optional[MarketRegime]) -> float:
        if not regime or not isinstance(regime.regime, dict):
            return 0.5
        liquidity = (regime.regime.get("liquidity") or "normal").lower()
        if liquidity == "stressed":
            return 0.8
        if liquidity == "abundant":
            return 0.2
        return 0.5

    def _estimate_costs_bps(
        self,
        price: float,
        volatility_regime: str,
        predicted_direction: str,
        horizon: str,
        shares: int = DEFAULT_SHARES,
        daily_volume: Optional[float] = None,
    ) -> Tuple[float, Dict]:
        """
        Estimate comprehensive transaction costs in basis points.

        Args:
            price: Current price per share
            volatility_regime: Market volatility regime (low/medium/high/stressed)
            predicted_direction: Trade direction (up/down/flat) - affects overnight & borrow costs
            horizon: Prediction horizon (1d/5d/20d) - affects time-based costs
            shares: Number of shares to trade
            daily_volume: Average daily trading volume (for liquidity analysis)

        Returns:
            Tuple of (total_bps, breakdown_dict)
        """
        if price <= 0:
            return 0.0, {}

        cost_params = self.config.get("cost_parameters", {})

        # 1. Commission costs
        commission_config = cost_params.get("commission", {})
        commission_per_share = commission_config.get("per_share", 0.005)
        min_commission = commission_config.get("min_commission", 1.0)
        commission = max(commission_per_share * shares, min_commission)
        commission_bps = (commission / (price * shares)) * 10000

        # 2. Spread costs (volatility-dependent)
        vol_key = (volatility_regime or "medium").lower()
        spread_config = cost_params.get("spread_bps", {})
        spread_bps = spread_config.get(f"{vol_key}_volatility", spread_config.get("medium_volatility", 8.0))

        # 3. Slippage costs
        slippage_config = cost_params.get("slippage_bps", {})
        slippage_bps = slippage_config.get("high_volatility", 9.0) if vol_key == "high" or vol_key == "stressed" else slippage_config.get("normal", 5.0)

        # 4. Market impact (volume-aware if daily_volume provided)
        impact_bps = self._calculate_market_impact(price, shares, daily_volume, vol_key)

        # 5. Overnight financing costs (time-based, direction-dependent)
        overnight_bps = self._calculate_overnight_costs(predicted_direction, horizon)

        # 6. Short borrow costs (only for short positions)
        borrow_bps = self._calculate_borrow_costs(predicted_direction, horizon)

        # 7. Regulatory fees (SEC + FINRA)
        regulatory_config = cost_params.get("regulatory_fees", {})
        sec_fee_bps = regulatory_config.get("sec_fee_bps", 0.278)
        finra_fee_bps = regulatory_config.get("finra_taf_bps", 0.013)
        regulatory_bps = sec_fee_bps + finra_fee_bps

        # Total costs
        total_bps = (
            commission_bps +
            spread_bps +
            slippage_bps +
            impact_bps +
            overnight_bps +
            borrow_bps +
            regulatory_bps
        )

        breakdown = {
            "commission_bps": round(commission_bps, 3),
            "spread_bps": round(spread_bps, 3),
            "slippage_bps": round(slippage_bps, 3),
            "market_impact_bps": round(impact_bps, 3),
            "overnight_cost_bps": round(overnight_bps, 3),
            "borrow_cost_bps": round(borrow_bps, 3),
            "regulatory_bps": round(regulatory_bps, 3),
            "total_bps": round(total_bps, 3),
        }
        return total_bps, breakdown

    def _calculate_market_impact(
        self,
        price: float,
        shares: int,
        daily_volume: Optional[float],
        vol_regime: str
    ) -> float:
        """Calculate dynamic market impact based on order size vs daily volume."""
        impact_config = self.config.get("cost_parameters", {}).get("market_impact_bps", {})

        if daily_volume and daily_volume > 0:
            # Volume-aware calculation
            participation_pct = (shares / daily_volume) * 100
            volume_threshold = impact_config.get("volume_threshold_pct", 1.0)

            if participation_pct <= volume_threshold:
                return impact_config.get("small_order", 6.0)
            elif participation_pct <= volume_threshold * 3:
                # Scale linearly between small and medium
                return impact_config.get("medium_order", 12.0)
            else:
                # Large order - exponential penalty
                base_impact = impact_config.get("large_order", 25.0)
                # Add penalty for stressed vol
                stress_multiplier = 1.5 if vol_regime == "stressed" else 1.0
                return base_impact * stress_multiplier
        else:
            # Fallback to simple share-based calculation
            return impact_config.get("small_order", 6.0) if shares <= 100 else impact_config.get("medium_order", 12.0)

    def _calculate_overnight_costs(self, predicted_direction: str, horizon: str) -> float:
        """Calculate overnight financing fees based on holding period."""
        financing_config = self.config.get("cost_parameters", {}).get("overnight_financing", {})

        # Convert horizon to days
        horizon_days = {"1d": 1, "5d": 5, "20d": 20}.get(horizon, 5)

        # Direction determines if long or short position
        if predicted_direction == "down":
            # Short position - higher overnight costs
            cost_per_day = financing_config.get("short_position_bps_per_day", 1.4)
        else:
            # Long position (up or flat)
            cost_per_day = financing_config.get("long_position_bps_per_day", 1.1)

        return cost_per_day * horizon_days

    def _calculate_borrow_costs(self, predicted_direction: str, horizon: str) -> float:
        """Calculate short-selling borrow costs (only applies to short positions)."""
        if predicted_direction != "down":
            return 0.0  # No borrow costs for long positions

        borrow_config = self.config.get("cost_parameters", {}).get("short_borrow_costs", {})

        # Assume "easy to borrow" for most liquid stocks
        # In production, this should be determined by stock-specific data
        annual_pct = borrow_config.get("easy_to_borrow_annual_pct", 0.5)

        # Convert to bps for the holding period
        horizon_days = {"1d": 1, "5d": 5, "20d": 20}.get(horizon, 5)
        borrow_bps = (annual_pct / 100) * (horizon_days / 365) * 10000

        return borrow_bps

    def _get_market_snapshot(self, ticker: str) -> Optional[Dict]:
        now = datetime.utcnow()
        cached = self._market_cache.get(ticker)
        if cached and now - cached["timestamp"] <= self._market_cache_ttl:
            return cached["data"]

        data = self.market_data_provider.get_live_price(ticker)
        if not data:
            return None

        self._market_cache[ticker] = {"timestamp": now, "data": data}
        return data

    def _calculate_decision(
        self,
        predicted_direction: str,
        expected_return_pct: float,
        confidence: float,
        risk_score: float,
        cost_ratio: float,
        position_constraints: Optional[Dict] = None,
    ) -> Tuple[str, Dict]:
        """
        Calculate trading decision with position sizing constraints.

        Returns:
            Tuple of (decision, constraint_info)
        """
        constraint_info = {
            "blocked_by": [],
            "position_size_ok": True,
            "liquidity_ok": True,
            "risk_ok": True
        }

        # Standard decision thresholds
        if confidence < self.MIN_CONFIDENCE:
            constraint_info["blocked_by"].append(f"confidence ({confidence:.2%} < {self.MIN_CONFIDENCE:.2%})")
            return "hold", constraint_info

        if abs(expected_return_pct) < self.MIN_EXPECTED_RETURN_PCT:
            constraint_info["blocked_by"].append(f"expected_return ({abs(expected_return_pct):.2f}% < {self.MIN_EXPECTED_RETURN_PCT:.2f}%)")
            return "hold", constraint_info

        if risk_score > self.MAX_RISK_SCORE:
            constraint_info["blocked_by"].append(f"risk_score ({risk_score:.2f} > {self.MAX_RISK_SCORE:.2f})")
            constraint_info["risk_ok"] = False
            return "hold", constraint_info

        if cost_ratio > self.MAX_COST_RATIO:
            constraint_info["blocked_by"].append(f"cost_ratio ({cost_ratio:.2f} > {self.MAX_COST_RATIO:.2f})")
            return "hold", constraint_info

        # Position sizing constraints (if provided)
        if position_constraints:
            position_size_pct = position_constraints.get("position_size_pct", 0)
            max_position_size = self.config.get("position_constraints", {}).get("max_position_size_pct", 10.0)

            if position_size_pct > max_position_size:
                constraint_info["blocked_by"].append(f"position_size ({position_size_pct:.1f}% > {max_position_size:.1f}%)")
                constraint_info["position_size_ok"] = False
                return "hold", constraint_info

            # Liquidity constraints
            daily_volume_usd = position_constraints.get("daily_volume_usd", 0)
            min_liquidity = self.config.get("position_constraints", {}).get("min_liquidity_usd", 100000)

            if daily_volume_usd > 0 and daily_volume_usd < min_liquidity:
                constraint_info["blocked_by"].append(f"liquidity (${daily_volume_usd:,.0f} < ${min_liquidity:,.0f})")
                constraint_info["liquidity_ok"] = False
                return "hold", constraint_info

        # All constraints passed - make direction-based decision
        if predicted_direction == "up" and expected_return_pct > 0:
            return "buy", constraint_info
        if predicted_direction == "down" and expected_return_pct < 0:
            return "sell", constraint_info

        return "hold", constraint_info

    def simulate_prediction(
        self,
        db: Session,
        prediction: Prediction,
        entity: Entity,
    ) -> Optional[TradingSimulation]:
        if not prediction or not entity:
            return None

        existing = db.query(TradingSimulation).filter(
            TradingSimulation.prediction_id == prediction.prediction_id
        ).first()

        predicted_direction = self._get_predicted_direction(prediction)
        expected_return_pct = self._get_expected_return_pct(prediction)
        confidence = prediction.calibrated_confidence or prediction.confidence or 0.0

        # Try to get live performance data first
        performance = self.performance_service.get_prediction_performance(prediction, entity)
        actual_return_pct = performance.get("total_return_pct") if performance else None
        
        # FALLBACK: Check PredictionOutcome table if live data unavailable
        if actual_return_pct is None:
            from src.models.predictions import PredictionOutcome
            outcome = db.query(PredictionOutcome).filter(
                PredictionOutcome.prediction_id == prediction.prediction_id
            ).first()
            if outcome and outcome.actual_return is not None:
                actual_return_pct = outcome.actual_return
                logger.info(f"Using saved PredictionOutcome for {entity.entity_id}: {actual_return_pct:.2f}%")
            else:
                logger.warning(f"No actual return data available for {entity.entity_id} (prediction {prediction.prediction_id})")
        
        # Calculate divergence only when actual data exists
        divergence_pct = None
        if actual_return_pct is not None:
            divergence_pct = expected_return_pct - actual_return_pct
        else:
            # Don't default to expected - leave as None to indicate missing data
            pass

        regime = self._get_latest_regime(db)
        volatility_regime = None
        regime_confidence = None
        if regime:
            volatility_regime = (regime.regime or {}).get("volatility")
            regime_confidence = (regime.regime_probabilities or {}).get("current_regime_confidence")

        market_snapshot = self._get_market_snapshot(entity.entity_id)
        price = market_snapshot.get("price") if market_snapshot else 0.0
        daily_volume = market_snapshot.get("volume") if market_snapshot else None
        total_cost_bps, cost_breakdown = self._estimate_costs_bps(
            price=price,
            volatility_regime=volatility_regime,
            predicted_direction=predicted_direction,
            horizon=prediction.horizon,
            daily_volume=daily_volume
        )
        expected_return_bps = abs(expected_return_pct) * 100.0
        cost_ratio = total_cost_bps / expected_return_bps if expected_return_bps > 0 else 1.0

        # Calculate risk-adjusted position size
        # Start with a FIXED DOLLAR AMOUNT baseline (not fixed shares!)
        assumed_portfolio_value = 100000  # $100k default portfolio
        baseline_dollar_position = 5000  # $5k baseline position (5% of portfolio)
        baseline_position_size_pct = (baseline_dollar_position / assumed_portfolio_value) * 100
        
        # Calculate daily volume and initial metrics for risk calculation
        daily_volume_usd = (daily_volume * price) if daily_volume and price > 0 else 0

        # First, calculate risk WITHOUT position adjustment
        risk_inputs = RiskInputs(
            model_uncertainty=1.0 - min(max(confidence, 0.0), 1.0),
            divergence_pct=divergence_pct,
            volatility_regime=volatility_regime,
            liquidity_stress=self._regime_liquidity_stress(regime),
            regime_confidence=regime_confidence,
            transaction_cost_ratio=min(max(cost_ratio, 0.0), 1.0),
            market_impact_bps=cost_breakdown.get("market_impact_bps", 0.0),
            correlation_breakdown=None,
            position_size_pct=baseline_position_size_pct,
            daily_volume_usd=daily_volume_usd,
        )
        risk_result = self.risk_calculator.calculate(risk_inputs)
        
        # Now adjust position size based on risk score (INVERSE relationship)
        # Higher risk = smaller position
        # risk_result is a Dict with keys: risk_score, component_scores, weights
        risk_score = risk_result["risk_score"]
        max_position_pct = self.config.get("position_constraints", {}).get("max_position_size_pct", 10.0)
        
        # Risk-adjusted position sizing: reduce position as risk increases
        # Formula: baseline * (1 - risk_score) with floor at 20% of baseline
        risk_adjustment_factor = max(0.2, 1.0 - risk_score)
        position_size_pct = baseline_position_size_pct * risk_adjustment_factor
        
        # Cap at max_position_pct
        position_size_pct = min(position_size_pct, max_position_pct)
        
        # Calculate actual position value based on adjusted size
        position_value = (assumed_portfolio_value * position_size_pct) / 100

        position_constraints = {
            "position_size_pct": position_size_pct,
            "daily_volume_usd": daily_volume_usd,
        }

        decision, constraint_info = self._calculate_decision(
            predicted_direction=predicted_direction,
            expected_return_pct=expected_return_pct,
            confidence=confidence,
            risk_score=risk_result["risk_score"],
            cost_ratio=cost_ratio,
            position_constraints=position_constraints,
        )

        simulation_payload = {
            "predicted_direction": predicted_direction,
            "actual_direction": performance.get("actual_direction") if performance else None,
            "strategy_result": performance.get("strategy_result") if performance else None,
            "market_snapshot": {
                "price": price,
                "change_percent": market_snapshot.get("change_percent") if market_snapshot else None,
                "timestamp": market_snapshot.get("timestamp").isoformat() if market_snapshot else None,
                "volume": daily_volume,
                "volume_usd": daily_volume_usd,
            },
            "position_info": {
                "shares": self.DEFAULT_SHARES,
                "position_value_usd": position_value,
                "position_size_pct": position_size_pct,
                "assumed_portfolio_value": assumed_portfolio_value,
            },
            "constraints": constraint_info,
            "cost_details": {
                **cost_breakdown,
                "cost_ratio": cost_ratio,
                "expected_return_bps": expected_return_bps,
            }
        }

        if existing:
            existing.decision = decision
            existing.expected_return_pct = expected_return_pct
            existing.actual_return_pct = actual_return_pct
            existing.divergence_pct = divergence_pct
            existing.risk_score = risk_result["risk_score"]
            existing.confidence = prediction.confidence
            existing.calibrated_confidence = prediction.calibrated_confidence
            existing.transaction_cost_bps = total_cost_bps
            existing.overnight_cost_bps = cost_breakdown.get("overnight_cost_bps")
            existing.borrow_cost_bps = cost_breakdown.get("borrow_cost_bps")
            existing.position_size_pct = position_size_pct
            existing.position_value_usd = position_value
            existing.cost_breakdown = cost_breakdown
            existing.risk_breakdown = risk_result["components"]
            existing.simulation_metadata = simulation_payload
            existing.created_at = datetime.utcnow()
            return existing

        simulation = TradingSimulation(
            prediction_id=prediction.prediction_id,
            entity_id=prediction.entity_id,
            horizon=prediction.horizon,
            decision=decision,
            expected_return_pct=expected_return_pct,
            actual_return_pct=actual_return_pct,
            divergence_pct=divergence_pct,
            risk_score=risk_result["risk_score"],
            confidence=prediction.confidence,
            calibrated_confidence=prediction.calibrated_confidence,
            transaction_cost_bps=total_cost_bps,
            overnight_cost_bps=cost_breakdown.get("overnight_cost_bps"),
            borrow_cost_bps=cost_breakdown.get("borrow_cost_bps"),
            position_size_pct=position_size_pct,
            position_value_usd=position_value,
            cost_breakdown=cost_breakdown,
            risk_breakdown=risk_result["components"],
            simulation_metadata=simulation_payload,
            created_at=datetime.utcnow(),
        )
        db.add(simulation)
        return simulation

    def process_batch(self, limit: int = 50, lookback_days: int = 7) -> Dict:
        """Simulate trades for recent predictions."""
        cutoff = datetime.utcnow() - timedelta(days=lookback_days)
        stats = {
            "processed": 0,
            "created": 0,
            "updated": 0,
            "skipped": 0,
            "errors": 0,
        }

        with get_scoped_session() as db:
            predictions = db.query(Prediction).filter(
                Prediction.created_at >= cutoff
            ).order_by(Prediction.created_at.desc()).limit(limit).all()

            if not predictions:
                return stats

            for prediction in predictions:
                try:
                    entity = db.query(Entity).filter(
                        Entity.entity_id == prediction.entity_id
                    ).first()
                    if not entity:
                        stats["skipped"] += 1
                        continue

                    existing = db.query(TradingSimulation).filter(
                        TradingSimulation.prediction_id == prediction.prediction_id
                    ).first()

                    simulation = self.simulate_prediction(db, prediction, entity)
                    if not simulation:
                        stats["skipped"] += 1
                        continue

                    stats["processed"] += 1
                    if existing:
                        stats["updated"] += 1
                    else:
                        stats["created"] += 1
                except Exception as e:
                    logger.error(f"Error simulating prediction {prediction.prediction_id}: {e}")
                    stats["errors"] += 1

        return stats

    def get_statistics(self) -> Dict:
        """Get simulation statistics."""
        with get_scoped_session() as db:
            total = db.query(TradingSimulation).count()
            buys = db.query(TradingSimulation).filter(TradingSimulation.decision == "buy").count()
            sells = db.query(TradingSimulation).filter(TradingSimulation.decision == "sell").count()
            holds = db.query(TradingSimulation).filter(TradingSimulation.decision == "hold").count()

            return {
                "total_simulations": total,
                "buys": buys,
                "sells": sells,
                "holds": holds,
            }

    def delete_simulation(self, simulation_id: str) -> bool:
        """Delete a simulation by ID."""
        try:
            with get_scoped_session() as db:
                simulation = db.query(TradingSimulation).filter(
                    TradingSimulation.simulation_id == simulation_id
                ).first()
                if simulation:
                    db.delete(simulation)
                    db.commit()
                    logger.info(f"Deleted simulation {simulation_id}")
                    return True
                logger.warning(f"Simulation {simulation_id} not found")
                return False
        except Exception as e:
            logger.error(f"Error deleting simulation {simulation_id}: {e}")
            return False

    def refresh_simulation(self, simulation_id: str) -> bool:
        """Refresh/recalculate a simulation by ID."""
        try:
            with get_scoped_session() as db:
                simulation = db.query(TradingSimulation).filter(
                    TradingSimulation.simulation_id == simulation_id
                ).first()
                if not simulation:
                    logger.warning(f"Simulation {simulation_id} not found")
                    return False

                prediction = db.query(Prediction).filter(
                    Prediction.prediction_id == simulation.prediction_id
                ).first()
                if not prediction:
                    logger.warning(f"Prediction {simulation.prediction_id} not found")
                    return False

                entity = db.query(Entity).filter(
                    Entity.entity_id == prediction.entity_id
                ).first()
                if not entity:
                    logger.warning(f"Entity {prediction.entity_id} not found")
                    return False

                # Recalculate the simulation
                self.simulate_prediction(db, prediction, entity)
                db.commit()
                logger.info(f"Refreshed simulation {simulation_id}")
                return True
        except Exception as e:
            logger.error(f"Error refreshing simulation {simulation_id}: {e}")
            return False

    def create_simulations_from_predictions(
        self,
        prediction_ids: Optional[List[str]] = None,
        entity_filter: Optional[List[str]] = None,
        horizon_filter: Optional[str] = None,
        date_range: Optional[Tuple[datetime, datetime]] = None,
        limit: int = 100,
    ) -> Dict:
        """Create simulations from specific predictions or filters."""
        stats = {
            "processed": 0,
            "created": 0,
            "updated": 0,
            "skipped": 0,
            "errors": 0,
        }

        with get_scoped_session() as db:
            query = db.query(Prediction)

            if prediction_ids:
                query = query.filter(Prediction.prediction_id.in_(prediction_ids))
            else:
                if entity_filter:
                    query = query.filter(Prediction.entity_id.in_(entity_filter))
                    logger.info(f"Filtering by entities: {entity_filter}")
                if horizon_filter and horizon_filter != "all":
                    query = query.filter(Prediction.horizon == horizon_filter)
                    logger.info(f"Filtering by horizon: {horizon_filter}")
                if date_range and len(date_range) == 2:
                    start, end = date_range
                    if start:
                        query = query.filter(Prediction.created_at >= start)
                    if end:
                        query = query.filter(Prediction.created_at <= end)
                    logger.info(f"Filtering by date range: {start} to {end}")

            predictions = query.order_by(Prediction.created_at.desc()).limit(limit).all()
            
            logger.info(f"Found {len(predictions)} predictions matching filters (limit: {limit})")

            if not predictions:
                logger.warning("No predictions found matching the filters")
                return stats

            for prediction in predictions:
                try:
                    entity = db.query(Entity).filter(
                        Entity.entity_id == prediction.entity_id
                    ).first()
                    if not entity:
                        logger.warning(f"Entity not found for prediction {prediction.prediction_id}, entity_id: {prediction.entity_id}")
                        stats["skipped"] += 1
                        continue

                    existing = db.query(TradingSimulation).filter(
                        TradingSimulation.prediction_id == prediction.prediction_id
                    ).first()

                    simulation = self.simulate_prediction(db, prediction, entity)
                    if not simulation:
                        logger.debug(f"Simulation skipped for prediction {prediction.prediction_id}")
                        stats["skipped"] += 1
                        continue

                    stats["processed"] += 1
                    if existing:
                        stats["updated"] += 1
                        logger.debug(f"Updated simulation for prediction {prediction.prediction_id}")
                    else:
                        stats["created"] += 1
                        logger.debug(f"Created simulation for prediction {prediction.prediction_id}")
                except Exception as e:
                    logger.error(f"Error simulating prediction {prediction.prediction_id}: {e}", exc_info=True)
                    stats["errors"] += 1

            db.commit()

        return stats
